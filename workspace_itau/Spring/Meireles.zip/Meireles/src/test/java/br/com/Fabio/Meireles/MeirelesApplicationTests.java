package br.com.Fabio.Meireles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeirelesApplicationTests {

	@Test
	void contextLoads() {
	}

}
